# Inventory Management System

## Project Overview:
 
 Inventory Management System developed by ASP.NET as front end and SQL SERVER as back end.The system used to keep truck of receives and sales transaction of business.

## Running Instruction:

 * Download the latest version with git (git clone   https://github.com/Abiyayalew/Inventory)    
 * From the project folder,open the SQL.txt file. 
 * Copy the scripts from text file.
 * Open SQL Server  and paste scripts to new query window and execute.
 * Run the application.


## Project Approaches:
 
 *	 Created and implemented using three layer architecture.
 *	 Implemented form based authentication. 
 *	 Form control validation, Printing and date time picker using JavaScript’.
 *	 Optimizing code using reusability.


 
















